package com.alpna.firebase.StudyMaterial;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.alpna.firebase.R;

public class StudyMaterial extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_study_material);
    }
}