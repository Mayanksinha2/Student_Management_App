package com.alpna.firebase.VideoLecture;

public class Model_VideoLecture {
}
