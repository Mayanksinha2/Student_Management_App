package com.alpna.firebase.VideoLecture;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.alpna.firebase.R;

public class VideoLecture extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_lecture);
    }
}