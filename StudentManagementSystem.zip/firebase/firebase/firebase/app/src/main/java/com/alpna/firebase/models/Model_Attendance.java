package com.alpna.firebase.models;

public class Model_Attendance {

    String intime,outtime,date,location;

    public Model_Attendance() {
    }

    public Model_Attendance(String intime, String outtime, String date, String location) {
        this.intime = intime;
        this.outtime = outtime;
        this.date = date;
        this.location = location;
    }

    public String getIntime() {
        return intime;
    }

    public void setIntime(String intime) {
        this.intime = intime;
    }

    public String getOuttime() {
        return outtime;
    }

    public void setOuttime(String outtime) {
        this.outtime = outtime;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
