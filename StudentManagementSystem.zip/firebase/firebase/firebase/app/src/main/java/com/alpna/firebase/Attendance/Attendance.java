package com.alpna.firebase.Attendance;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;

import com.alpna.firebase.R;
import com.alpna.firebase.models.Model_Attendance;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

public class Attendance extends AppCompatActivity {

    FirebaseFirestore db;
    RecyclerView recyclerView;
    Myadapter_Attendance myadapter_attendance;
    ArrayList<Model_Attendance> holder = new ArrayList<>();

    String email;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance);

        db = FirebaseFirestore.getInstance();
        recyclerView = (RecyclerView) findViewById(R.id.recyclerRV);
        email = FirebaseAuth.getInstance().getCurrentUser().getEmail();

        myadapter_attendance = new Myadapter_Attendance(datafetch(),getApplicationContext());
        recyclerView.setAdapter(myadapter_attendance);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(Attendance.this,LinearLayoutManager.VERTICAL,false);
        recyclerView.setLayoutManager(linearLayoutManager);
//datafetch();

    }



    public ArrayList<Model_Attendance> datafetch(){






        db.collection("Student Data").document(email)
                .collection("Attendence")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            for (QueryDocumentSnapshot document : task.getResult()) {
                                Log.d("TAG1", document.getId() + " => " + document.getData());
                                Model_Attendance obj = new Model_Attendance();


                                String d = document.getId();
                                String it = document.getData().get("InTime").toString();
                                String ot = document.getData().get("OutTime").toString();
                                String ll  = document.getData().get("Live Location").toString();
                                obj.setDate(d);
                                obj.setIntime(it);
                                obj.setOuttime(ot);
                                obj.setLocation(ll);
                                holder.add(obj);

                                myadapter_attendance.notifyDataSetChanged();
                                   Log.e("LogE", (String) document.getData().get("InTime"));

                            }
//
//                            recyclerView.notifyAll();
                            myadapter_attendance.notifyDataSetChanged();
                        } else {
                            Log.d("TAG2", "Error getting documents: ", task.getException());
                        }
                    }
                });



        return holder;
    }
}