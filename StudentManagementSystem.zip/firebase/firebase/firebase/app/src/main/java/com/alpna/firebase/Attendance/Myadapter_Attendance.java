package com.alpna.firebase.Attendance;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.alpna.firebase.R;
import com.alpna.firebase.models.Model_Attendance;

import java.util.ArrayList;

public class Myadapter_Attendance extends RecyclerView.Adapter<Myadapter_Attendance.MyViewHolder>
{

    ArrayList <Model_Attendance> data;
    Context context;

    public Myadapter_Attendance(ArrayList<Model_Attendance> data, Context context) {
        this.data = data;
        this.context = context;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.attendance_layout,parent,false);


        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        String d = data.get(position).getDate();
        int sd = Integer.parseInt(d.substring(3,5));

        if(sd==06)
            holder.linearlayout.setBackgroundColor(Color.RED);
        if(sd==07)
            holder.linearlayout.setBackgroundColor(Color.GREEN);

        holder.dTV.setText("Date:-"+d);
        holder.inTV.setText("InTime:-"+data.get(position).getIntime());
        holder.outTV.setText("OutTime"+data.get(position).getOuttime());

        if (!data.get(position).getLocation().equals(""))
            holder.llTV.setText(data.get(position).getLocation().substring(0,30));
        else
         holder.llTV.setText(data.get(position).getLocation());

    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder
    {
        TextView dTV,inTV,outTV,llTV;
        LinearLayout linearlayout;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            dTV = itemView.findViewById(R.id.dateTV);
            inTV = itemView.findViewById(R.id.intimeTV);
            outTV = itemView.findViewById(R.id.outTV);
            llTV = itemView.findViewById(R.id.llTV);
            linearlayout = itemView.findViewById(R.id.linearLL);



        }
    }
}
